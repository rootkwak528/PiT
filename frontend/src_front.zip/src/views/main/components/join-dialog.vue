<template>
  <el-dialog custom-class="join-dialog" title="회원가입" v-model="state.dialogVisible" @close="handleClose">
    <el-form v-loading="loading" :model="state.form" :rules="state.rules" ref="joinForm" :label-position="state.form.align">
      <el-form-item prop="department" label="소속" :label-width="state.formLabelWidth" >
        <el-input v-model="state.form.department" autocomplete="off" @input="onInputForm"></el-input>
      </el-form-item>
      <el-form-item prop="job" label="직책" :label-width="state.formLabelWidth">
        <!-- <el-input v-model="state.form.job" autocomplete="off" @input="onInputForm"></el-input> -->
        <el-radio v-model="state.form.job" label="001">관리자</el-radio>
        <el-radio v-model="state.form.job" label="002">트레이너</el-radio>
        <el-radio v-model="state.form.job" label="003">수강생</el-radio>
      </el-form-item>
      <el-form-item prop="name" label="이름" :label-width="state.formLabelWidth">
        <el-input v-model="state.form.name" autocomplete="off" @input="onInputForm"></el-input>
      </el-form-item>
      <el-form-item prop="id" label="아이디" :label-width="state.formLabelWidth">
        <el-input style="float:left; width:70%" v-model="state.form.id" autocomplete="off" @input="onInputIdForm"></el-input>
        <el-button style="float:right; width:28%" type="primary" @click="checkDuplicationId">중복 확인</el-button>
      </el-form-item>
      <el-form-item prop="password" label="비밀번호" :label-width="state.formLabelWidth">
        <el-input v-model="state.form.password" autocomplete="off" show-password @input="onInputForm"></el-input>
      </el-form-item>
      <el-form-item prop="passwordChk" label="비밀번호 확인" :label-width="state.formLabelWidth">
        <el-input v-model="state.form.passwordChk" autocomplete="off" show-password @input="onInputForm"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button v-if="!joinValid" type="primary" @click="clickJoin" disabled>가입하기</el-button>
        <el-button v-else type="primary" @click="clickJoin">가입하기</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<style>
.join-dialog {
  width: 500px !important;
  height: 550px;
}
.join-dialog .el-dialog__headerbtn {
  float: right;
}
.join-dialog .el-form-item__content {
  margin-left: 0 !important;
  float: right;
  width: 200px;
  display: inline-block;
}
.join-dialog .el-form-item {
  margin-bottom: 20px;
}
.join-dialog .el-form-item__error {
  font-size: 12px;
  color: red;
}
.join-dialog .el-input__suffix {
  display: none;
}
.join-dialog .el-dialog__footer {
  margin: 0 calc(50% - 80px);
  padding-top: 0;
  display: inline-block;
}
.join-dialog .dialog-footer .el-button {
  width: 120px;
}
</style>
<script>
import { reactive, computed, ref, onMounted } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'join-dialog',

  props: {
    open: {
      type: Boolean,
      default: false
    }
  },

  setup(props, { emit }) {
    const store = useStore()
    // 마운드 이후 바인딩 될 예정 - 컨텍스트에 노출시켜야함. <return>
    const joinForm = ref(null)
    const joinValid = ref(false)
    const isIdAvailable = ref(false)
    const loading = ref(false)

    /*
      // Element UI Validator
      // rules의 객체 키 값과 form의 객체 키 값이 같아야 매칭되어 적용됨
      //
    */
    const validateDepartment = (rule, value, callback) => {
      if (value.length > 30) {
        callback(new Error('최대 30자까지 입력 가능합니다.'))
      } else {
        callback()
      }
    }

    const validateName = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('필수 입력 항목입니다.'))
      } else if (value.length > 30) {
        callback(new Error('최대 30자까지 입력 가능합니다.'))
      } else {
        callback()
      }
    }

    const validateId = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('필수 입력 항목입니다.'))
      } else if (value.length > 16) {
        callback(new Error('최대 16자까지 입력 가능합니다.'))
      } else {
        callback()
      }
    }

    const validatePassword = (rule, value, callback) => {
      const num = value.search(/[0-9]/g)
      const eng = value.search(/[a-z]/ig)
      const spe = value.search(/[`~!@#$%^&*|₩₩₩'₩";:₩/?]/gi)

      if (value === '') {
        callback(new Error('필수 입력 항목입니다.'))
      } else if (value.length < 9 ) {
        callback(new Error('최소 9 글자를 입력해야 합니다.'))
      } else if (value.length > 16) {
        callback(new Error('최대 16자까지 입력 가능합니다.'))
      } else if (num < 0 || eng < 0 || spe < 0) {
        callback(new Error('비밀번호는 영문, 숫자, 특수문자가 조합되어야 합니다.'))
      } else {
        callback()
      }
    }

    const validatePasswordChk = (rule, value, callback) => {
      const num = value.search(/[0-9]/g)
      const eng = value.search(/[a-z]/ig)
      const spe = value.search(/[`~!@#$%^&*|₩₩₩'₩";:₩/?]/gi)

      if (value === '') {
        callback(new Error('필수 입력 항목입니다.'))
      } else if (value.length < 9 ) {
        callback(new Error('최소 9 글자를 입력해야 합니다.'))
      } else if (value.length > 16) {
        callback(new Error('최대 16자까지 입력 가능합니다.'))
      } else if (num < 0 || eng < 0 || spe < 0) {
        callback(new Error('비밀번호는 영문, 숫자, 특수문자가 조합되어야 합니다.'))
      } else if (value !== state.form.password) {
        callback(new Error('입력한 비밀번호와 일치하지 않습니다.'))
      } else {
        callback()
      }
    }

    const state = reactive({
      form: {
        department: '',
        job: '003',
        name: '',
        id: '',
        password: '',
        passwordChk: '',
        align: 'left'
      },
      rules: {
        department: [
          { validator: validateDepartment, trigger: 'blur' },
        ],
        job: [
          { required: true, trigger: 'blur' }
        ],
        name: [
          { required: true, validator: validateName, trigger: 'blur' }
        ],
        id: [
          { required: true, validator: validateId, trigger: 'blur' }
        ],
        password: [
          { required: true, validator: validatePassword, trigger: 'blur' }
        ],
        passwordChk: [
          { required: true, validator: validatePasswordChk, trigger: 'blur' }
        ]
      },
      dialogVisible: computed(() => props.open),
      formLabelWidth: '120px'
    })

    onMounted(() => {
      console.log(joinForm.value)
    })

    const clickJoin = function () {
      // 로그인 클릭 시 validate 체크 후 그 결과 값에 따라, 로그인 API 호출 또는 경고창 표시
      joinForm.value.validate((valid) => {
        if (valid) {
          console.log('submit')

          loading.value = true
          store.dispatch('root/requestJoin', { userDept: state.form.department, userType: state.form.job, userName: state.form.name, userId: state.form.id, userPwd: state.form.password })
          .then(function (result) {

            // localStorage 에 jwt 토큰 저장
            alert("회원 가입이 완료되었습니다.")
            loading.value = false
            emit('closeJoinDialog')
          })
          .catch(function (err) {
            alert(err.response.data.message)
            loading.value = false
            emit('closeJoinDialog')
          })
        } else {
          alert('회원 가입에 실패하였습니다.')
        }
      });
    }

    const handleClose = function () {
      state.form.department = ''
      state.form.job = '003'
      state.form.name = ''
      state.form.id = ''
      state.form.password = ''
      state.form.passwordChk = ''
      emit('closeJoinDialog')
    }

    const checkDuplicationId = function () {
      joinForm.value.validateField('id', (err) => {
        if (err === '') {
          store.dispatch('root/checkDuplicationId', { userId: state.form.id })
          .then(result => {
            alert('사용 가능한 아이디입니다.')
            isIdAvailable.value = true
            onInputForm()
          })
          .catch(err => {
            // 409 error 처리해줘야 함!

            alert(err.response.data.message)
          })
        }
      })
    }

    const onInputForm = function () {
      joinForm.value.validate((valid) => {
        joinValid.value = valid & isIdAvailable.value
      })
    }

    const onInputIdForm = function () {
      isIdAvailable.value = false
      onInputForm()
    }

    return { joinForm, joinValid, isIdAvailable, loading, state, clickJoin, handleClose, checkDuplicationId, onInputForm, onInputIdForm }
  }
}
</script>
