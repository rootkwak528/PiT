<template>
  <el-container class="main-wrapper">
    <main-header
      :height="`70px`"
      @openLoginDialog="onOpenLoginDialog"
      @openJoinDialog="onOpenJoinDialog"
    />
    <el-container class="main-container">
      <el-aside class="hide-on-small" width="240px">
        <main-sidebar
          :width="`240px`"
        />
      </el-aside>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
    <main-footer :height="`110px`"/>
  </el-container>
  <login-dialog
    :open="loginDialogOpen"
    @closeLoginDialog="onCloseLoginDialog"/>
  <join-dialog
    :open="joinDialogOpen"
    @closeJoinDialog="onCloseJoinDialog"/>
</template>
<style>
  @import "https://unpkg.com/element-plus/lib/theme-chalk/index.css";
  @import './main.css';
  @import '../../common/css/common.css';
  @import '../../common/css/element-plus.css';

</style>
<script>
import LoginDialog from './components/login-dialog'
import JoinDialog from './components/join-dialog'
import MainHeader from './components/main-header'
import MainSidebar from './components/main-sidebar'
import MainFooter from './components/main-footer'

export default {
  name: 'Main',
  components: {
    MainHeader,
    MainSidebar,
    MainFooter,
    LoginDialog,
    JoinDialog
  },
  data () {
    return {
      loginDialogOpen: false,
      joinDialogOpen: false,
    }
  },
  methods: {
    onOpenLoginDialog () {
      this.loginDialogOpen = true
    },
    onCloseLoginDialog () {
      this.loginDialogOpen = false
    },
    onOpenJoinDialog () {
      this.joinDialogOpen = true
    },
    onCloseJoinDialog () {
      this.joinDialogOpen = false
    }
  },
  created(){
    //this.$store.state.isLogined = true
    if (localStorage.getItem('jwt-auth-token')) {
      if (
        localStorage.getItem('jwt-auth-token') != '' &&
        localStorage.getItem('jwt-auth-token') != null
      ) {
        // this.$store.state.isLogined = true
        this.$store.dispatch('root/requestUserInfo', { token: localStorage.getItem('jwt-auth-token') })
          .then(function (result) {
            alert('유저 정보 조회 성공')
            console.log(result.data)
          })
          .catch(function (err) {
            console.log(err)
            if(err.response.data.statusCode == 401){
              // 임시코드
              if(err.response.data.message == "SignatureVerificationException" || err.response.data.message == "JWTDecodeException"){
                alert("세션이 유효하지 않습니다.")
                localStorage.removeItem('jwt-auth-token')
                store.commit('root/setIsLogined')
                router.push('/')
              }else if(err.response.data.message == "TokenExpiredException"){
                alert("세션이 만료되었습니다.")
                localStorage.removeItem('jwt-auth-token')
                store.commit('root/setIsLogined')
                router.push('/')
              }
            }else if(err.response.data.statusCode == 403){
              if(err.response.data.message == "Forbidden"){
                alert("접근 권한이 없습니다.")
              }
            }
          })
      }
    } else {
      localStorage.setItem('jwt-auth-token', '');
    }
    console.log(this.$store.state.isLogined)
  }
}
</script>
